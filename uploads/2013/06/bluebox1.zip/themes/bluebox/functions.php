<?php 
    /*--------------- [ 网站临时维护 ] -----------------*/
    /*function wp_maintenance_mode(){
        if(!current_user_can('edit_themes') || !is_user_logged_in()){
            wp_die('<meta charset="UTF8" />
网站临时维护中，请稍后...', '网站临时维护中，请稍后...', array('response' => '503'));
        }
    }
    add_action('get_header', 'wp_maintenance_mode');*/
    
    /*--------------- [ wp_head() 的处理 ] -----------------*/

    remove_action( 'wp_head', 'wp_shortlink_wp_head', 10, 0 ); //删除短链接shortlink
    remove_action( 'wp_head', 'wp_generator' ); //删除版权
    remove_action( 'wp_head', 'feed_links_extra', 3 ); //删除包含文章和评论的feed
    remove_action( 'wp_head', 'rsd_link' ); //删除外部编辑器
    remove_action( 'wp_head', 'wlwmanifest_link' ); //删除外部编辑器
    remove_action( 'wp_head', 'adjacent_posts_rel_link_wp_head', 10, 0 ); //删除上一篇下一篇
    add_filter('show_admin_bar','__return_false'); //移除admin条
    foreach(array('comment_text','the_content','the_excerpt','the_title') as $xx)
    remove_filter($xx,'wptexturize'); //禁止半角符号自动变全角
    remove_filter('comment_text','capital_P_dangit',31);
    remove_filter('the_content','capital_P_dangit',11);
    remove_filter('the_title','capital_P_dangit',11); //禁止自动把’Wordpress’之类的变成’WordPress’

    /*--------------- [ 自定义登录失败的信息 ] -----------------*/

       /***********************************************
        *                增强网站安全性。
	*  我们知道，当我们输入一个存在的用户名，但是输入错误的密码
        *  wordpress默认会返回的信息是该账户的密码不正确，
        *  这就等于告诉黑客确实存在这样的账户，方便了黑客进行下一步行动。
	***********************************************/

    function failed_login() {
        return 'Incorrect login information.';
    }
    add_filter('login_errors', 'failed_login');
    
    /*--------------- [ 多说 移到底部 ] -----------------*/

   /* add_action('init', 'move_duoshuo_js_to_footer');
    function move_duoshuo_js_to_footer() {
	global $duoshuoPlugin;
	remove_action('wp_print_scripts', array($duoshuoPlugin, 'appendScripts'));
	add_action('wp_footer',array($duoshuoPlugin, 'appendScripts'));
     }*/

    /*--------------- [ 为前后页添加class ] -----------------*/
    add_filter('next_posts_link_attributes','add_next',10,0);
    function add_next(){
        $class = 'class="next"';
        return $class;
    }
    
    add_filter('previous_posts_link_attributes','add_previous',10,0);
    function add_previous(){
        $class = 'class="prev"';
        return $class;
    }
    
    /*--------------- [ 菜单 ] -----------------*/

    add_theme_support('nav-menus');

    if( function_exists('register_nav_menus') )
    {   
        register_nav_menus( array( 'homepage' => __( '主页菜单' ),'friends' => __( '友情链接' )  ) );
    }


    /*---------------- [ 获取缩略图 ]------------------*/
    
    add_theme_support( 'post-thumbnails' );

    function post_thumbnail( $width = 100,$height = 80 , $extraClass="" ,$moreInfo = "" ){
        global $post;
        if( has_post_thumbnail() ){    //如果有缩略图，则显示缩略图
            $timthumb_src = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID),'full');
             $post_timthumb = '<img src="'.get_bloginfo("template_url").'/timthumb.php?src='.$timthumb_src[0].'&amp;h='.$height.'&amp;w='.$width.'&amp;zc=1" alt="'.$post->post_title.'" class="' . $extraClass.'"  height="'.$height.'" width="'.$width.'" '.$moreInfo.' />';
            echo $post_timthumb;
        } else {
            $post_timthumb = '';
            ob_start();
            ob_end_clean();
            $output = preg_match('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $index_matches);    //获取日志中第一张图片
            $first_img_src = $index_matches [1];    //获取该图片 src
            if( !empty($first_img_src) ){    //如果日志中有图片
                $path_parts = pathinfo($first_img_src);    //获取图片 src 信息
                $first_img_name = $path_parts["basename"];    //获取图片名
                $first_img_pic = get_bloginfo('wpurl'). '/cache/'.$first_img_name;    //文件所在地址
                $first_img_file = ABSPATH. 'cache/'.$first_img_name;    //保存地址
                $expired = 604800;    //过期时间
                if ( !is_file($first_img_file) || (time() - filemtime($first_img_file)) > $expired ){
                    copy($first_img_src, $first_img_file);    //远程获取图片保存于本地
                    $post_timthumb = '<img src="'.$first_img_src.'" alt="'.$post->post_title.'" class="thumb" />';    //保存时用原图显示
                }
                $post_timthumb = '<img src="'.get_bloginfo("template_url").'/timthumb.php?src='.$first_img_pic.'&amp;h='.$height.'&amp;w='.$width.'&amp;zc=1" alt="'.$post->post_title.'" class="' . $extraClass.'"   height="'.$height.'" width="'.$width.'" '.$moreInfo.' />';
            } else {    //如果日志中没有图片，则显示默认
                 $post_timthumb = '<img src="'.get_bloginfo("template_url").'/timthumb.php?src='.get_bloginfo("template_url").'/img/default.png&amp;h='.$height.'&amp;w='.$width.'&amp;zc=1" alt="'.$post->post_title.'" class="' . $extraClass.'"   height="'.$height.'" width="'.$width.'" '.$moreInfo.' />';
            }
            echo $post_timthumb;
        }
    };

     /*---------------- [ 随机文章 ]------------------*/
    function random_posts($posts_num=5,$before='<li>',$after='</li>'){
        global $wpdb;
        $sql = "SELECT ID, post_title,guid
                FROM $wpdb->posts
                WHERE post_status = 'publish' ";
        $sql .= "AND post_title != '' ";
        $sql .= "AND post_password ='' ";
        $sql .= "AND post_type = 'post' ";
        $sql .= "ORDER BY RAND() LIMIT 0 , $posts_num ";
        $randposts = $wpdb->get_results($sql);
        $output = '';
        foreach ($randposts as $randpost) {
            $post_title = stripslashes($randpost->post_title);
            $permalink = get_permalink($randpost->ID);
            $output .= $before.'<a href="'
                . $permalink . '"  rel="bookmark" title="';
            $output .= $post_title . '">' . $post_title . '</a>';
            $output .= $after;
        }
        echo $output;
    }

    function wp_pagenavi( $p = 3 ) {
          if ( is_singular() ) return;
          global $wp_query, $paged;
          $max_page = $wp_query->max_num_pages;
          if ( $max_page == 1 ) return;
          if ( empty( $paged ) ) $paged = 1;
          echo '<div class="wp-pagenavi pagination pull-center"><ul>';
          if ( $paged > 4 ) p_link( 1, '|<' );
          if ( $paged > 1 ) p_link( $paged-1, '«' );
          for( $i = $paged - $p ; $i <= $paged + $p ; $i++ ) {
            if ( $i > 0 && $i <= $max_page ) 
                $i == $paged ? print "<li><span class='current'>{$i}</span></li> " : p_link( $i );
          }
          if ( $paged < $max_page ) p_link( $paged+1, '»' );
          if ( $paged < $max_page-3 ) p_link( $max_page, '>|' );
          echo '</ul></div>';
    };
    function p_link( $i, $title = '' ) {
          if ( $title == '' ) $title = "{$i}";
          echo "<li><a href='", esc_html( get_pagenum_link( $i ) ), "'>{$title}</a></li>";
    };

?>