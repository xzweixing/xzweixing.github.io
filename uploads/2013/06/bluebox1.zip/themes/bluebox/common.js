var duoshuoQuery = {short_name:"多说评论框ID"};
	(function() {
		var ds = document.createElement('script');
		ds.type = 'text/javascript';ds.async = true;
		ds.src = 'http://static.duoshuo.com/embed.js';
		ds.charset = 'UTF-8';
		(document.getElementsByTagName('head')[0] 
		|| document.getElementsByTagName('body')[0]).appendChild(ds);
	})();

$(function() {
    var win_width = $(window).width();
    var wrap_width = $('#wrap').width();
    var totop_width = $('#totop').width();
    var totop_posi = ([win_width - wrap_width] / 2 - totop_width);
    $('#totop').css({
        'right': totop_posi
    });
    $(window).scroll(function() {
        if ($(window).scrollTop() >= 200)
        {
            $('#totop').slideDown(200);
        } else
        {
            $('#totop').slideUp(200);
        }
    });
    $('#totop').click(function() {
        $('body,html').animate({
            scrollTop: 0
        },
        300)
    });
})

window.onload=function(){
	$(window).scroll(function(){
		var posi = $("#main").height()-$("#menu").height()-10;
		if($(document).scrollTop()>=posi){
			$('#menu').css({'position':'absolute','top':posi});
		}else{
			$('#menu').css({'position':'fixed','top':0});
		}
	});
}