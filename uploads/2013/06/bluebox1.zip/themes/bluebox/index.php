<?php get_header(); ?>

	<div id="main">
		<?php if(have_posts()) : ?><?php while(have_posts()) : the_post(); ?>
		<div class="loop">
			<div class="content">
				<a href="<?php the_permalink(); ?>" title="<?php get_the_title(); ?>">		
					<?php post_thumbnail( 280,150 ) ;  ?>
				</a>
				<p><?php echo mb_strimwidth(strip_tags(get_the_content()), 0, 120,"..."); ?><span class="more"><a href="<?php the_permalink(); ?>" title="阅读全文">更多»</a></span></p>
			</div>
			<h3><a href="<?php the_permalink(); ?>" title="<?php get_the_title(); ?>"><?php echo mb_strimwidth(strip_tags(get_the_content()), 0, 32,"..."); ?></a></h3>
			<div class="date">
				<?php the_time('Y-n-j') ?>
				<div class="num">
					<a href="<?php the_permalink(); ?>#comments" title="评论"><span class="com"></span><span class="ds-thread-count" data-thread-key="<?php echo $post->ID ?>"></span></a>
				</div>
			</div>
		</div>
		<?php endwhile; ?>
		<div id="page">
			<?php previous_posts_link('&lt;'); ?>
			<?php next_posts_link('&gt;'); ?> 
		</div>
		<?php endif; ?>
	</div>	

<?php get_footer(); ?>