<div id="comments"> 
<!-- Duoshuo Comment BEGIN -->
	<div class="ds-thread" data-thread-key="<?php echo $post->ID ?>"
	data-title="<?php the_title(); ?>" data-author-key="<?php the_author_meta('ID') ?>" data-url=""></div>
<!-- Duoshuo Comment END -->
</div>