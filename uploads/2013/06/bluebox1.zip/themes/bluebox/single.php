<?php get_header(); ?>

    <div id="main">
		<div id="post">
			<div id="title">
				<?php if(have_posts()): ?><?php while(have_posts()):the_post();  ?>
				<img src="<?php bloginfo('template_url'); ?>/img/avatar.png" class="img" />
				<h1><?php the_title(); ?></h1>
				<div class="date">时间：<?php the_time('Y-n-j') ?>&nbsp;&nbsp;|&nbsp;&nbsp;评论：<span class="ds-thread-count" data-thread-key="<?php echo $post->ID ?>"></span> 条&nbsp;&nbsp;|&nbsp;&nbsp;<?php the_tags('标签：', ', ', ''); ?></div>
			</div>
			<div class="post">
				<?php the_content(); ?>
				<div id="share">
				<!-- Baidu Button BEGIN -->
				<div id="bdshare" class="bdshare_t bds_tools get-codes-bdshare">
					<span class="bdmore">分享：</span>
					<a class="bds_qzone"></a>
					<a class="bds_tsina"></a>
					<a class="bds_tqq"></a>
					<a class="bds_renren"></a>
					<a class="bds_tieba"></a>
				</div>
				<script type="text/javascript" id="bdshare_js" data="type=tools&amp;uid=231046"></script>
				<script type="text/javascript" id="bdshell_js"></script>
				<script type="text/javascript">
				document.getElementById("bdshell_js").src = "http://bdimg.share.baidu.com/static/js/shell_v2.js?cdnversion=" + Math.ceil(new Date()/3600000)
				</script>
				<!-- Baidu Button END -->
				</div>
			</div>
		</div>
		<?php comments_template(); ?>
		<?php endwhile; ?>
    </div>
    <?php endif; ?>
    
<?php get_footer(); ?>