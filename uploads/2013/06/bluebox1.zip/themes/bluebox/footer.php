</div>
<div id="footer">
	<div id="bottom">
		<?php if(is_home()) { ?>
		<div class="link">
			<h2>友情链接</h2>
			<?php 
			  		wp_nav_menu(
								  array(	
								  			'theme_location'   => 'friends',
											'sort_column'      => 'menu_order',
										) 
						 		); 
			?>
		</div>
		<?php ; } else { ?>
		<div class="random">
			<h2>随便看看</h2>
			<ul>
				<?php random_posts(); ?>
			</ul>
		</div>
		<?php ; } ?>
		<div class="tag">
			<h2>热门标签</h2>
			<ul>
				<?php wp_tag_cloud('smallest=12&largest=12&unit=px&number=22&order=DESC'); ?>
			</ul>
		</div>
		<div id="copyright">Copyright &copy; 2013 <?php bloginfo('name'); ?> All Rights Reserved. Theme by <a href="http://banri.me" target="_blank">Banri</a></div>
	</div>
	<div id="totop">▲</div>
</div>
<script src="<?php bloginfo('template_url'); ?>/common.js"></script>
<?php wp_footer(); ?>
</body>
</html>