<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<?php if(is_home()) : { ?>
    <title><?php bloginfo('name'); ?> - <?php bloginfo('description'); ?></title>
<?php ;} ?>
    
<?php else : ?>
    <title><?php wp_title(' - ', true, 'right'); ?> - <?php bloginfo('name'); ?></title>
<?php endif; ?>

<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" />
<script type="text/javascript" src="http://lib.sinaapp.com/js/jquery/1.7.2/jquery.min.js"></script>
<script type="text/javascript">
	!window.jQuery && document.write('<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"><\/script>');
</script>
<!--[if IE 6]>
	<script src="//letskillie6.googlecode.com/svn/trunk/2/zh_CN.js"></script>
<![endif]-->

<?php get_template_part( 'meta' ); ?>
	
<?php wp_head(); ?>

</head>
<body>
<div id="wrap">
	<div id="menu">
		<a href="/"><img src="<?php bloginfo('template_url'); ?>/img/logo.png" /></a>
		<?php 
		  		wp_nav_menu(
							  array(	
							  			'theme_location'   => 'homepage',
										'sort_column'      => 'menu_order',
										'menu_class'       => 'out',
										'link_before'      => '<span class="line">',
										'link_after'       => '</span>',
									) 
					 		); 
		?>
		<form id="search" method="post" action="/">
			<input type="text" name="s" value="搜索..." onfocus="if (value =='搜索...'){value =''}" onblur="if (value ==''){value='搜索...'}" x-webkit-speech lang="zh-CN" />
		</form>
	</div>
